package acc.br.pessoaSwagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoaSwaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
